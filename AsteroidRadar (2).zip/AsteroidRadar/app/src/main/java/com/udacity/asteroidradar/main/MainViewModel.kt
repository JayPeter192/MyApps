package com.udacity.asteroidradar.main

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import com.udacity.asteroidradar.api.parseAsteroidsJsonResult
import com.udacity.asteroidradar.Asteroid
import com.udacity.asteroidradar.PictureOfDay
import com.udacity.asteroidradar.database.AsteroidDao
import com.udacity.asteroidradar.database.AsteroidsDatabase.Companion.getDatabase
import com.udacity.asteroidradar.network.*
import com.udacity.asteroidradar.repository.AsteroidsRepository
import kotlinx.coroutines.*
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

enum class AsteroidFilter {WEEK, DAY, ALL}

class MainViewModel(application: Application
) : AndroidViewModel(application) {

    private val database = getDatabase(application)
    private val asteroidRepository = AsteroidsRepository(database)

    private val _navigateToSelectedAsteroid = MutableLiveData<Asteroid>()
    val navigateToSelectedAsteroid: LiveData<Asteroid>
        get() = _navigateToSelectedAsteroid

    init {
        viewModelScope.launch {
            asteroidRepository.refreshAsteroidsAndIOD()
        }
    }

    private val asteroidFilter = MutableLiveData<AsteroidFilter>(AsteroidFilter.ALL)

    val asteroids = Transformations.switchMap(asteroidFilter){
        when(it) {
            AsteroidFilter.DAY -> asteroidRepository.dayAsteroids
            AsteroidFilter.ALL -> asteroidRepository.allAsteroids
            AsteroidFilter.WEEK -> asteroidRepository.weekAsteroids
            else -> asteroidRepository.allAsteroids
        }
    }

    val pictureOfDay = asteroidRepository.pictureOfDay

    fun displayAsteroidDetails(asteroid: Asteroid){
        _navigateToSelectedAsteroid.value = asteroid
    }

    fun displayAsteroidDetailsCompleted() {
        _navigateToSelectedAsteroid.value = null
    }

    fun updateFilter(filter: AsteroidFilter){
        asteroidFilter.value = filter
    }
}