package com.udacity.asteroidradar.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.udacity.asteroidradar.database.AsteroidsDatabase
import com.udacity.asteroidradar.repository.AsteroidsRepository
import retrofit2.HttpException

class RefreshAsteroidsWorker(appContext: Context, params: WorkerParameters): CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            downloadDeleteAndUpdateAsteroids()
            Result.success()
        } catch (e:HttpException){
            Result.retry()
        }
    }

    private suspend fun downloadDeleteAndUpdateAsteroids()
    {
        val database = AsteroidsDatabase.getDatabase(applicationContext)
        val asteroidRepository = AsteroidsRepository(database)
        asteroidRepository.refreshAsteroidsAndIOD()
        asteroidRepository.deletePrevAsteroids()
    }

    companion object {
        const val WORK_NAME = "RefreshAsteroidsWorker"
    }
}