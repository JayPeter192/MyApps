package com.udacity.asteroidradar

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TextItemViewHolder(val asteroidsView: View): RecyclerView.ViewHolder(asteroidsView)
{
    private val textView: TextView = asteroidsView.findViewById(R.id.codename)
    fun bind(item: Asteroid){
        textView.text = item.codename
    }
}