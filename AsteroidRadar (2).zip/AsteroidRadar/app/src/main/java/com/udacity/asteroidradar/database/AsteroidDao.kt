package com.udacity.asteroidradar.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.udacity.asteroidradar.Asteroid

@Dao
interface AsteroidDao {
    @Query("SELECT * from asteroid_table ORDER BY close_approach_date")
    fun getAsteroids(): LiveData<List<DatabaseAsteroid>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(asteroids: List<DatabaseAsteroid>)

    @Query("DELETE from asteroid_table WHERE close_approach_date =:date")
    fun deletePreviousDaysAsteroids(date: String)

    @Query("SELECT * FROM asteroid_table WHERE close_approach_date =:date")
    fun getTodaysAsteroids(date: String): LiveData<List<DatabaseAsteroid>>

    @Query("SELECT * FROM asteroid_table WHERE close_approach_date >= :startDate AND close_approach_date <= :endDate ORDER BY close_approach_date")
    fun getThisWeeksAsteroids(startDate: String, endDate: String): LiveData<List<DatabaseAsteroid>>
}