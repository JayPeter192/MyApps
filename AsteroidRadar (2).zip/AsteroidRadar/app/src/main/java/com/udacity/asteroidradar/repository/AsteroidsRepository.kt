package com.udacity.asteroidradar.repository

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.udacity.asteroidradar.Asteroid
import com.udacity.asteroidradar.Constants
import com.udacity.asteroidradar.PictureOfDay
import com.udacity.asteroidradar.api.*
import com.udacity.asteroidradar.database.AsteroidsDatabase
import com.udacity.asteroidradar.database.asDomainModel
import com.udacity.asteroidradar.network.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class AsteroidsRepository (private val database: AsteroidsDatabase) {

    private val _pictureOfDay = MutableLiveData<PictureOfDay>()
    val pictureOfDay: LiveData<PictureOfDay>
        get() = _pictureOfDay

    suspend fun refreshAsteroidsAndIOD() {
        try {
            withContext(Dispatchers.IO) {
                val asteroidResponse = AsteroidApi.retrofitService.getAsteroids(getTodaysDate(), getEndOfWeekDate(),Constants.API_KEY)
                val asteroids = parseAsteroidsJsonResult(JSONObject(asteroidResponse))
                database.asteroidDao.insertAll(NetworkAsteroidContainer(asteroids).asDatabaseModel())
1            }
        } catch (e: Exception) {
            Log.e("MainViewModel", "No Internet, cant refresh")
            e.printStackTrace()
        }.also {
            try{
                   val picture = PictureOfDayApi.retrofitService.getPictureOfDay(Constants.API_KEY)
                _pictureOfDay.value = picture
            }catch (e: Exception)
            {
                Log.e("MainViewModel", "Error getting picture of day.")
                e.printStackTrace()
            }
        }
    }

    var weekAsteroids: LiveData<List<Asteroid>> =
        Transformations.map(database.asteroidDao.getThisWeeksAsteroids(getTodaysDate(), getEndOfWeekDate())){
            it.asDomainModel()
        }
    var dayAsteroids: LiveData<List<Asteroid>> =
        Transformations.map(database.asteroidDao.getTodaysAsteroids(getTodaysDate())){
            it.asDomainModel()
        }
    var allAsteroids: LiveData<List<Asteroid>> =
        Transformations.map(database.asteroidDao.getAsteroids()){
            it.asDomainModel()
        }

    suspend fun deletePrevAsteroids() {
        try {
            withContext(Dispatchers.IO) {
                database.asteroidDao.deletePreviousDaysAsteroids(getPreviousDaysFormattedDate())
            }
        } catch (e: Exception) {
            Log.e("MainViewModel", "Can't Delete Asteroids")
            e.printStackTrace()
        }
    }

}
